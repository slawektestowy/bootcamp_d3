x = float(input('Podaj liczbe: '))
#if x == 7:
#    print ('Ta liczba to 7')
#else:
#    print ("Ta liczba jest podzielna przez 3: ", x % 3 == 0)
#    print ("Ta liczba jest nieparzysta: ", x % 2 != 0)
#    print("Ta liczba jest wieksza od 10: ", x > 10)


print ('Ta liczba to 7', x==7,'\n'
       "Ta liczba jest podzielna przez 3: ", x % 3 == 0,'\n',
       "Ta liczba jest nieparzysta: ", x % 2 != 0,'\n',
       "Ta liczba jest wieksza od 10: ", x > \10)