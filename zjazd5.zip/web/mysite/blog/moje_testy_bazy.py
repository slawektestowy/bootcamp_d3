from web.mysite.blog.models import Post

lista_obiektow = Post.objects.all()

print(lista_obiektow)