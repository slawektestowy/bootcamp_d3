import numpy as np
import analiza_danych.bmp as bmp
from scipy import ndimage

data = bmp.read_bmp('dane/tiger.bmp')

# wycinanie koloru
print(data.shape)
# data = data.transpose((1,0,2))
# data = data.swapaxes(0,1)
# data = np.array(data.swapaxes(0,1)[::-1]).swapaxes(0,1)
# data = data * np.array([False,True,True])

data = ndimage.gaussian_filter(data, sigma=[0, 0, 1])
print(data.shape)
bmp.write_bmp('dane/kot.bmp', data)