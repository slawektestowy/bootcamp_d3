a = int(input('Podaj wysokosc w cm: '))
b = int(input('Podaj szerokosc w cm: '))
c = int(input('Podaj glebokosc: w cm: '))
d = a*b*c
print('Objetosc: {d}')
print('Objetosc jest wieksza od litra', d > 1000)