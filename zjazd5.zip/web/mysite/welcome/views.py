from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def hello_view(request):
    return HttpResponse(content="CZeść! Witaj Świecie")

def hello_name_view(request, name):
    return HttpResponse(content=f"Cześć {name}! Jak się masz? :)")

def hello_fullname_view(request, name, surname):
    return HttpResponse(content=f"Cześć {name} {surname}! Jak się masz? :)")

def numer_view(request, a):
    t = str(type(a))
    return HttpResponse(content=f'argument: {a+1000} typu {t}')