w = int(input('Podaj rok urodzenia: '))
x = 2018
if x-w >=18:
    print('jestes pelnoletni')
else:
    print('jestes niepelnoletni')