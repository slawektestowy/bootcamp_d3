from django.contrib import admin

from .models import Autor, Post

admin.site.register(Autor)
admin.site.register(Post)
