from django.contrib import admin
from .models import Produkt

admin.site.register(Produkt)
