
from django.urls import path

from .views import hello_view, hello_name_view, hello_fullname_view, numer_view

urlpatterns = [
    path('', hello_view),
    path('<int:a>', numer_view),

    path('<name>', hello_name_view),

    path('<name>/<surname>', hello_fullname_view),
]
