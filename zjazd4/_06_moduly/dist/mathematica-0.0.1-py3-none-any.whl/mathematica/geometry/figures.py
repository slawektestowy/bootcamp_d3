# square_area oraz triangle_area
def square_area(a):
    return a**2

def triangle_area(a, h):
    return a*h/2