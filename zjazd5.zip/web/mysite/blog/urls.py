from django.urls import path
from .views import index_view, post_details_view

urlpatterns = [
    path('', index_view),
    path('post/<int:post_id>', post_details_view, name='post_details')
]
