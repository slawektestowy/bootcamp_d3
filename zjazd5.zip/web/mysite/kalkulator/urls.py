
from django.urls import path
from .views import calc_view, help_view

urlpatterns = [
    path('', help_view),
    path('<op>/<int:a>/<int:b>', calc_view),

]
