from django.shortcuts import render, get_list_or_404, get_object_or_404

from .models import Post, Autor


def index_view(request):
    # post_list = get_list_or_404(Post)
    # post_list = Post.objects.all()
    # post_list = Post.objects.filter(tresc__startswith = 'J')
    # autor = Autor.objects.filter(imie__endswith = 'n')
    post_list = Post.objects.filter(autor__imie__startswith = 'P')
    return render(request=request,
                  template_name='blog/post_list.html',
                  context={'post_list':post_list
                           ,'top':5
                           ,'sort-asc':True
                           ,'logo':'...sciezka dostepu...'} )

def post_details_view(request, post_id):
    # post = get_object_or_404(Post, pk=post_id)
    post = Post.objects.get(id=post_id)
    return render(request=request,
                  template_name='blog/post_details.html',
                  context={'post':post})