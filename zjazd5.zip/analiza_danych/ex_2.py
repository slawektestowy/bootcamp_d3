import argparse

import numpy as np
from scipy import ndimage

import analiza_danych.bmp as bmp


def parse_args():
    parser = argparse.ArgumentParser('Process BMP file')
    parser.add_argument('--input', help='input file', required=True)
    parser.add_argument('--output', help='output file', required=True)
    parser.add_argument('--rotate', help='rotate image', type=int)
    parser.add_argument('--blur', help='blur image', action='store_true')
    parser.add_argument('--black-white', help='black-white filter', action='store_true')
    parser.add_argument('--color', help='choose single color (RED, GREEN, BLUE)', type=str)
    parser.add_argument('--cut', help='cut image fragment', action='store_true')
    return parser.parse_args()


# dodaj opcję wycinania kawałka obrazka


def main():
    args = parse_args()
    data = bmp.read_bmp(args.input)

    if args.rotate:
        data = ndimage.rotate(data, angle=args.rotate)
    if args.blur:
        data = ndimage.gaussian_filter(data, sigma=[3, 3, 0])
    if args.black_white:
        sum_array = data.sum(axis=2, keepdims=True) / 3
        data = np.ones(3) * sum_array
    if args.color:
        data = data * np.array([args.color == 'BLUE', args.color == 'GREEN', args.color == 'RED'])
    if args.cut:
        data = data[220:320, 300:400]

    bmp.write_bmp(args.output, data)

    a = np.array([[[1, 2, 3], [4, 5, 6], [200, 100, 0]],
                  [[1, 2, 3], [4, 5, 6], [200, 100, 0]]])
    kolor = np.array([True, False, True])
    print(a*kolor)


if __name__ == '__main__':
    main()
