from django.http import HttpResponse
from django.shortcuts import render

def help_view(request):
    return HttpResponse(content=f"użyj operacji 'add' lub 'sub':<br>"
                                f"/kalkulator/add/4/5<br>"
                                f"/kalkulator/sub/10/3<br>")

def calc_view(request,op, a, b):
    if op == 'add':
        ret = HttpResponse(content=f"wynik: {a + b}")
    elif op == 'sub':
        ret = HttpResponse(content=f"wynik: {a - b}")
    else:
        ret = HttpResponse(content=f"niepoprawna operacja {op}")
    return ret