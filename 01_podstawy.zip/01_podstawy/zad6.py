# if
#



x = float(input('Podaj liczbe: '))
if x > 10:
    print("Wieksza od 10")
else:
    print("Wieksza od 10")

print('Czy liczba wieksza od 10', x > 10)

if x <= 15:
    print("Mniejsza rowna 15")
else:
    print("Mniejsza rowna 15")

print('Czy liczba mneijsza rowna 15', x <= 15)

if x % 2 == 0:
    print("Podzielna przez 2")
else:
    print("Podzielna przez 2")

print('Czy liczba podzielna przez dwa', x % 2 == 0)