from django.apps import AppConfig


class KalkulatorConfig(AppConfig):
    name = 'kalkulator'
