import setuptools

setuptools.setup(
    name="mathematica",
    version="0.0.1",
    author="Agata Powalka",
    author_email="a.powalka@alx.pl",
    description="Test package",
    packages=setuptools.find_packages(exclude=['test']),

)