from django.db import models


class Post(models.Model):
    tytul = models.CharField(max_length=255)
    published = models.DateTimeField(name='published'
                                , verbose_name='Data publikacji'
                                , null=True)
    tresc = models.TextField(null=True)
    obrazek = models.ImageField(null=True, blank=True)
    autor = models.ForeignKey(to='Autor', on_delete=models.CASCADE, null=True, blank=True)
    # autor = models.ForeignKey(to='auth.User', on_delete=models.CASCADE, null=True)

    def __str__(self):
        return f'{self.published} {self.tytul}'


class Autor(models.Model):
    imie = models.CharField(max_length=50)
    nazwisko = models.CharField(max_length=50)
    plec = models.CharField(max_length=1,
                            choices=(('M', 'mezczyzna')
                                     , ('K', 'kobieta')
                                     , ('I', 'inne')),
                            default='I')

    def __str__(self):
        return f'{self.imie} {self.nazwisko} ({self.plec})'
